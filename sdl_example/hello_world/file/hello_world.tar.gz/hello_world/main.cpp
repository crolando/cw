// SDL2 hello_world example for clockwork gameshell warehouse.
// This will display a bitmap until you press the exit button.
//
// This example was built directly on the gameshell using ssh to invoke the
// compiler.  The commandline used for the build is:
// clang++ main.cpp -o hello_world -lSDL2
//
// To run binaries directly in the gameshell, you have to use Utils > DinguxCommander
// to navigate to the binary, and then "execute" it.
//
// This demo was largely adapted from this demo:
// Taken from: https://gist.github.com/fschr/92958222e35a823e738bb181fe045274

#include <SDL2/SDL.h>
#include <stdio.h>

#define SCREEN_WIDTH 320
#define SCREEN_HEIGHT 240

// Utility function to parse the event queue to see if escape was pressed.
bool escape_pressed(void) {
  SDL_Event event;
  while (SDL_PollEvent(&event)) {
	  switch (event.type) {
		  case SDL_KEYDOWN:
			if (event.key.keysym.sym == SDLK_ESCAPE) {
				return true;
			}
			break;
	  }
  }
  return false;
}

// Entry point of the program
int main(int argc, char* args[]) {
  SDL_Window* window = NULL;
  SDL_Surface* screenSurface = NULL;
  
  // Intialization of SDL Subsystem with error handling -------------------------------------------
  if (SDL_Init(SDL_INIT_VIDEO) < 0) {
    fprintf(stderr, "Could not initialize sdl2: %s\n", SDL_GetError());
    return -1;
  } else {
	printf("Initialized SDL2, bud\n");
  }
  
  // Intialization of Window  with error handling -------------------------------------------------
  window = SDL_CreateWindow(
			    "hello_sdl2",
			    SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
			    SCREEN_WIDTH, SCREEN_HEIGHT,
			    SDL_WINDOW_SHOWN
			    );
  if (window == NULL) {
    fprintf(stderr, "Could not create window: %s\n", SDL_GetError());
    return -2;
  } else {
	printf("Created the SDL window, bud\n");
  }  
  

  // Loading bmp texture off the disk with error handling  ----------------------------------------
  SDL_Surface* texture = SDL_LoadBMP("hello_world.bmp");
  if(!texture) {
	  printf("LoadBMP Failed: %s\n", SDL_GetError());
	  return -3;
  }
  
  // This is the draw loop. ----------------------------------------------------------------------- 
  // It draws the screen, conducts game logic (there is none, so I wait for 33ms)
  // and then processes input.
  screenSurface = SDL_GetWindowSurface(window);
  bool exit_requested = false;
  while(!exit_requested) {
	// Check for events...
    exit_requested = escape_pressed();
	
	// Wait 33ms, so we don't draw the screen at a higher rate than the screen can draw,
	// and drain the battery.
    SDL_Delay(33);
	
	// Draw the screen (bitmap).
	SDL_BlitSurface(texture,NULL,screenSurface,NULL);
    SDL_UpdateWindowSurface(window);
	
 }
 
  // Cleanup the resources we reserved.
  SDL_DestroyWindow(window);
  SDL_Quit();
  
  // Exit with success return code
  return 0;
}


