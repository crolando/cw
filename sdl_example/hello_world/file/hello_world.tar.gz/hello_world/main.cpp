// SDL2 Hello, World!
// This should display a white screen for 2 seconds
// compile with: clang++ main.cpp -o hello_world -lSDL2
// run with: ./hello_sdl2

// Taken from: https://gist.github.com/fschr/92958222e35a823e738bb181fe045274

#include <SDL2/SDL.h>
#include <stdio.h>

#define SCREEN_WIDTH 320
#define SCREEN_HEIGHT 240

bool escape_pressed(void) {
  SDL_Event event;
  while (SDL_PollEvent(&event)) {
	  switch (event.type) {
		  case SDL_KEYDOWN:
			if (event.key.keysym.sym == SDLK_ESCAPE) {
				return true;
			}
			break;
	  }
  }
  return false;
}

int main(int argc, char* args[]) {
  SDL_Window* window = NULL;
  SDL_Surface* screenSurface = NULL;
  if (SDL_Init(SDL_INIT_VIDEO) < 0) {
    fprintf(stderr, "could not initialize sdl2: %s\n", SDL_GetError());
    return 1;
  } else {
	printf("Initialized sdl2, my man");
  }
  window = SDL_CreateWindow(
			    "hello_sdl2",
			    SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
			    SCREEN_WIDTH, SCREEN_HEIGHT,
			    SDL_WINDOW_SHOWN
			    );
  if (window == NULL) {
    fprintf(stderr, "could not create window: %s\n", SDL_GetError());
    return 1;
  } else {
	printf("Created the window, my man");
  }
  screenSurface = SDL_GetWindowSurface(window);
  bool exit_requested = false;
  char gray = 0;
  SDL_Surface* texture = SDL_LoadBMP("hello_world.bmp");
  if(!texture) {
	  printf("LoadBMP Failed: %s\n", SDL_GetError());
  }

  while(!exit_requested) {
	if(texture) {
		SDL_BlitSurface(texture,NULL,screenSurface,NULL);
	} else {
		SDL_FillRect(screenSurface, NULL, SDL_MapRGB(screenSurface->format, gray, gray, gray));
	}
	
    SDL_UpdateWindowSurface(window);
	// roughly 60fps
    SDL_Delay(33);
    // Check for events...
    exit_requested = escape_pressed();
	// change gray value
	gray = (gray + 1) % 255;
 }
  SDL_DestroyWindow(window);
  SDL_Quit();
  return 0;
}


