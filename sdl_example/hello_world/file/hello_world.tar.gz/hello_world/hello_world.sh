#!/bin/bash
./hello_world > log 2>&1