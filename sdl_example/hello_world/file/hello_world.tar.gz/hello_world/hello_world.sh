#!/bin/bash
./hello_world 2>1 log.txt