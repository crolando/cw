#!/bin/bash
./hello_world
